/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: PIC10
 * Board:    PIC10F32x Development Board
 * Compiler: MPLAB XC8
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@126.com
 * Date:     2015-Sept
 *
 */

#include "uhd.h"

// Configuration Bits
#pragma config FOSC = INTOSC    // Oscillator Selection bits (INTOSC oscillator: CLKIN function disabled)
#pragma config WDTE = SWDTEN    // WDT Controlled by SWDTEN
#pragma config MCLRE = OFF      // set MCLRE and LVP, let MCLR as IO input instead of RESET
#pragma config LVP = OFF

// PIC10F32x Development Board configuration
#define LED1    A, 1
#define LED2    A, 0
#define POT     A, 2
#define BUTTON  A, 3

void main(void)
{
    uint8_t adc;
    uint8_t cnt;

    // set LED1/LED2 as digital output
    IO_dir(LED1, IO_OUTPUT);
    IO_dir(LED2, IO_OUTPUT);
    
    // use PWM_freq_sysdiv and PWM_out will
    // save flash size notable
    
    // set PWM frequency 8000000/1600 = 5000Hz
    PWM_freq_sysdiv(PWM_FREQ_SYSDIV_16);
    
    // set PWM_1 duty 50%
    PWM_out(PWM_1, PWM_ON, 50);

    // set PWM_2 duty 20%, invert mode
    PWM_out(PWM_2, PWM_ON, 20);

    // enable ADC
    ADC_enable();
	
    while (1)
    {
        // get POT adc value
        adc = ADC_get(2);

        // set POT value to PWM_1 duty
        PWM_out(PWM_1, PWM_ON, adc/2);

        // change PWM_2 duty
        cnt += 2;
        if(cnt > 100)
            cnt = 0;
        PWM_out(PWM_2, PWM_ON, cnt);
        
        // delay 50ms
        delay_MS(50);
    }
}
