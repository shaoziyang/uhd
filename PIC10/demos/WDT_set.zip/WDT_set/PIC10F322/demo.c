/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: PIC10
 * Board:    PIC10F32x Development Board
 * Compiler: MPLAB XC8
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@126.com
 * Date:     2015-Sept
 *
 */

#include "uhd.h"

// Configuration Bits
#pragma config FOSC = INTOSC    // Oscillator Selection bits (INTOSC oscillator: CLKIN function disabled)
#pragma config WDTE = SWDTEN    // WDT Controlled by SWDTEN
#pragma config MCLRE = OFF      // set MCLRE and LVP, let MCLR as IO input instead of RESET
#pragma config LVP = OFF

// PIC10F32x Development Board configuration
#define LED1    A, 1
#define LED2    A, 0
#define POT     A, 2
#define BUTTON  A, 3

void tmr_2_isr(void)
{
    IO_inv(LED2);
}

void main(void)
{
    uint8_t i;
    
    // set LED1/LED2 as digital output
    IO_dir(LED1, IO_OUTPUT);
    IO_dir(LED2, IO_OUTPUT);
    
    IO_set(LED1);
    IO_clr(LED2);
    
    for(i = 20; i > 0; i--)
    {
        IO_inv(LED1);
        IO_inv(LED2);
        delay_MS(50);
    }
    
    WDT_set(WDTO_1S);
    
    while (1)
    {
        if(IO_in(BUTTON) == IO_LOW)
            while(1);
        
        delay_MS(5);
        WDT_clr();
        i++;
        if(i > 50)
        {
            i = 0;
            IO_inv(LED2);
        }
    }
}
