/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     uhdcutdown.h
 * Descript: Define function cutdown, for smaller code size.
 *           Before use this file, set marco _UHD_CUTDOWN_ to 1 in uhd.h
 *
 * Platform: PIC10
 * Compiler: MPLAB XC8
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@126.com
 * Date:     2015-Sept
 *
 */
 
#ifndef _UHD_CUTDOWN_H_
#define _UHD_CUTDOWN_H_ 1

// cutdown OSC
#define _UHD_OSC_CUTDOWN_       1

// cutdown ADC
#define _UHD_ADC_CUTDOWN_       0

// cutdown TIMER
#define _UHD_TMR_CUTDOWN_       1

// cutdown WDT
#define _UHD_WDT_CUTDOWN_       1

// cutdown PWM
#define _UHD_PWM_CUTDOWN_       0

// cutdown ENTINT
#define _UHD_EXTINT_CUTDOWN_    1

// cutdown PININT
#define _UHD_PININT_CUTDOWN_    1

// cutdown INTERRUPT
#define _UHD_ISR_CUTDOWN_       1


#endif
