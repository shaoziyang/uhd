/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: PIC10
 * Board:    PIC10F32x Development Board
 * Compiler: MPLAB XC8
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@126.com
 * Date:     2015-Sept
 *
 */

#include "uhd.h"

// Configuration Bits
#pragma config FOSC = INTOSC    // Oscillator Selection bits (INTOSC oscillator: CLKIN function disabled)
#pragma config WDTE = SWDTEN    // WDT Controlled by SWDTEN
#pragma config MCLRE = OFF      // set MCLRE and LVP, let MCLR as IO input instead of RESET
#pragma config LVP = OFF

// PIC10F32x Development Board configuration
#define LED1    A, 1
#define LED2    A, 0
#define POT     A, 2
#define BUTTON  A, 3

// user PININT isr
void myPININT_isr()
{
    // check POT/RA2
    if(PININT_flag(PININT_2))
    {
        // clear flag, must clear by user
        PININT_flag_clr(PININT_2);
        IO_inv(LED2);
    }
    // check BUTTON/RA3
    if(PININT_flag(PININT_3))
    {
        // clear flag
        PININT_flag_clr(PININT_3);
        if(IO_in(BUTTON))
            IO_clr(LED1);
        else
            IO_set(LED1);
    }
}

void main(void)
{
    // set LED1/LED2 as digital output
    IO_dir(LED1, IO_OUTPUT);
    IO_dir(LED2, IO_OUTPUT);
    
    IO_clr(LED1);
    IO_clr(LED2);

    // ENABLE digital input for RA2
    IO_digital(POT);

    // set PININT pin
    PININT_set(PININT_2, PININT_POSITIVE_EDGE);
    PININT_set(PININT_3, PININT_POSITIVE_NEGATIVE_EDGE);
    
    // PININT initial
    PININT_init(myPININT_isr);
    
    // Enable global interrupt
    ENABLE_interrupt();
	
    while (1)
    {
        //SLEEP();
    }
}
