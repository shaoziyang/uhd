/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: PIC10
 * Board:    PIC10F32x Development Board
 * Compiler: MPLAB XC8
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@126.com
 * Date:     2015-Sept
 *
 */

#include "uhd.h"

// Configuration Bits
#pragma config FOSC = INTOSC    // Oscillator Selection bits (INTOSC oscillator: CLKIN function disabled)
#pragma config WDTE = SWDTEN    // WDT Controlled by SWDTEN
#pragma config MCLRE = OFF      // set MCLRE and LVP, let MCLR as IO input instead of RESET
#pragma config LVP = OFF

#define LED1	A, 1
#define LED2	A, 0
#define POT		A, 2
#define BUTTON	A, 3

void main(void)
{
    // set LED1/RA1 as output
	IO_dir(LED1, IO_OUTPUT);
	
	while(1)
	{
        // blink LED1
        IO_inv(LED1);
		
        // delay 500ms
		delay_MS(500);
	}
}
