/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"
#include <stdio.h>

// define LED pin
#define LED     B, 5

// define PWM2 pin
#define PWM2A   B, 3
#define PWM2B   D, 3

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    
    // set PWM2 pin as output
    IO_dir(PWM2A, IO_OUTPUT);
    IO_dir(PWM2B, IO_OUTPUT);    

    // set PWM0 freq
    // PWM freq = MCU_freq/256 = 16000000/(256*256)
    PWM2_freq_sysdiv(PWM2_FREQ_SYSDIV_256);
    
    // set PWM out duty
    PWM2_duty(PWM2_OC2A, 25);
    PWM2_duty(PWM2_OC2B, 50);
    
    while(1)
    {

    }
}
