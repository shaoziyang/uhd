/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

// user TMR2 isr, it will effect by OSC_freq_div function
void tmr2_isr(void)
{
    IO_inv(LED);
}

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    
    // enable interrupt
    ENABLE_interrupt();
    
    while(1)
    {
        // set clock division
        // MCU_freq = 16000000/1
        // set TMR2_ticker interval to 500ms
        OSC_freq_div(OSC_DIV_1);
        TMR2_ticker(500, &tmr2_isr);
        delay_MS(5000);
        
        // set clock division to OSC_DIV_2
        // now MCU_freq = 16000000/2
        // TMR2_ticker interval change to 1000ms
        // it also effect delay_MS
        OSC_freq_div(OSC_DIV_2);
        delay_MS(5000/2);
        
        // set clock division to OSC_DIV_2
        // and set TMR2_ticker again
        // now TMR2_ticker interval is 500ms
        OSC_freq_div(OSC_DIV_2);
        TMR2_ticker(500, &tmr2_isr);
        delay_MS(5000/2);

    }
}
