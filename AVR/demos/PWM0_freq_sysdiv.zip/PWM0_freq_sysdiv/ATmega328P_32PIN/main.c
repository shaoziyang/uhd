/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"
#include <stdio.h>

// define LED pin
#define LED     B, 5

// define PWM0 pin
#define PWM0A  D, 6
#define PWM0B  D, 5


int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    
    // set PWM0 pin as output
    IO_dir(PWM0A, IO_OUTPUT);
    IO_dir(PWM0B, IO_OUTPUT);    

    // set PWM0 freq
    // PWM freq = MCU_freq/256 = 16000000/256
    PWM0_freq_sysdiv(PWM0_FREQ_SYSDIV_1);
    
    //PWM0_out(PWM0_OC0A, PWM_ON, 100);
    //PWM0_out(PWM0_OC0B, PWM_INVERT_PHASE, 200);
    
    // set PWM out duty
    PWM0_duty(PWM0_OC0A, 25);
    PWM0_duty_inv(PWM0_OC0B, 25);
    
    while(1)
    {

    }
}
