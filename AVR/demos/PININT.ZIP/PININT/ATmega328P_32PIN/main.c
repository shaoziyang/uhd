/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5
#define LED_2   B, 4
#define LED_3   B, 3
#define LED_4   B, 2

#define KEY0    D, 2
#define KEY1    D, 3
#define KEY2    B, 0
#define KEY3    C, 0

uint8_t STA0, STA1, STA2, STA3;

// user PININT isr
void myPININT_isr()
{
    if(STA0 != IO_in(KEY0))
    {
        STA0 = IO_in(KEY0);
        if(IO_in(KEY0) == IO_LOW)
            IO_inv(LED);
    }
    if(STA1 != IO_in(KEY1))
    {
        STA1 = IO_in(KEY1);
        IO_inv(LED_2);
    }
    if(STA2 != IO_in(KEY2))
    {
        STA2 = IO_in(KEY2);
        IO_inv(LED_3);
    }
    if(STA3 != IO_in(KEY3))
    {
        STA3 = IO_in(KEY3);
        IO_inv(LED_4);
    }
}


int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    IO_dir(LED_2, IO_OUTPUT);
    IO_clr(LED_2);
    IO_dir(LED_3, IO_OUTPUT);
    IO_clr(LED_3);
    IO_dir(LED_4, IO_OUTPUT);
    IO_clr(LED_4);
    
    // set INPUT and pullup
    IO_dir(KEY0, IO_INPUT);
    IO_pullup(KEY0, PULLUP_ENABLE);
    IO_dir(KEY1, IO_INPUT);
    IO_pullup(KEY1, PULLUP_ENABLE);    
    IO_pullup(KEY2, PULLUP_ENABLE);    
    IO_pullup(KEY3, PULLUP_ENABLE);    
    
    // save KEY stat
    STA0 = IO_in(KEY0);
    STA1 = IO_in(KEY1);
    STA2 = IO_in(KEY2);
    STA3 = IO_in(KEY3);
    
    // set PININT pin
    PININT_set(PININT_0, PININT_POSITIVE_NEGATIVE_EDGE);
    PININT_set(PININT_8, PININT_POSITIVE_NEGATIVE_EDGE);
    PININT_set(PININT_18, PININT_POSITIVE_NEGATIVE_EDGE);
    PININT_set(PININT_19, PININT_POSITIVE_NEGATIVE_EDGE);    
    
    // PININT initial
    PININT_init(myPININT_isr);
    
    // Enable global interrupt
    ENABLE_interrupt();
    
    while(1)
    {


    }
}
