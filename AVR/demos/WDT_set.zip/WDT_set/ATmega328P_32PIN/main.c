/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

#define BUTTON  B, 0

uint8_t cnt;
int main()
{
    IO_dir(LED, IO_OUTPUT);
    
    IO_dir(BUTTON, IO_INPUT);
    IO_pullup(BUTTON, PULLUP_ENABLE);
    
    for(cnt = 0; cnt < 10; cnt++)
    {
        delay_MS(50);
        IO_inv(LED);
    }
    
    WDT_set(WDTO_2S);
        
    while(1)
    {
        delay_MS(10);
        cnt++;
        if(cnt >= 50)
        {
            cnt = 0;
            IO_inv(LED);
        }
        WDT_clr();
        
        if(IO_in(BUTTON) == IO_LOW)
        {
            while(1)               // wait for WDT reset
                delay_MS(10);
        }
    }
}
