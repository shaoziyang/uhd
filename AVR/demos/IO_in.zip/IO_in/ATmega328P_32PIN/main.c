/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

// define IO
#define LED     B, 5

#define BUTTON  B, 0

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    
    // set input pin
    IO_dir(BUTTON, IO_INPUT);
    // enable pullup
    IO_pullup(BUTTON, PULLUP_ENABLE);
    
    while(1)
    {
        // check button status
        if(IO_in(BUTTON) == IO_LOW)
            IO_set(LED);
        else
            IO_clr(LED);
    }
}
