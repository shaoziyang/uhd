/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"
#include <stdio.h>

// define LED pin
#define LED     B, 5

// define PWM1 pin
#define PWM1A   B, 1
#define PWM1B   B, 2


int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    
    // set PWM1 pin as output
    IO_dir(PWM1A, IO_OUTPUT);
    IO_dir(PWM1B, IO_OUTPUT);    

    // set PWM1 freq
    // PWM freq = MCU_freq64 = 16000000/(64*256)
    PWM1_freq_sysdiv(PWM1_FREQ_SYSDIV_64);
    
    // set PWM out duty
    PWM1_duty(PWM1_OC1A, 33);
    PWM1_duty(PWM1_OC1B, 66);
    
    while(1)
    {

    }
}
