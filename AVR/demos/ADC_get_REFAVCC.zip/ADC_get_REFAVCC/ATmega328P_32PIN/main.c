/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"
#include <stdio.h>

#define LED     B, 5

uint16_t dat;
char buf[40];

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);

    // set AVCC as reference
    ADC_init(AREF_AVCC);

    // set uart baudrate
    UART0_init(9600, NULL, NULL, NULL);
    
    while(1)
    {
        delay_MS(500);

        // get ADC0
        dat = ADC_get(0);

        // printf adc result
        sprintf(buf, "ADC = %d, V = %ld\r\n", dat, dat*5000L/1024);
        UART0_puts(buf);

        IO_inv(LED);
    }
}
