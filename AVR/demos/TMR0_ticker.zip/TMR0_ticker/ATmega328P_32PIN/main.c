/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

// user isr function
void myTMR0_isr()
{
    IO_inv(LED);
}

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    
    // set TMR0 ticker, execute user isr every 2000ms
    TMR0_ticker(2000, myTMR0_isr);
    
    // enable interrupt
    ENABLE_interrupt();
    
    while(1)
    {

    }
}
