/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

// user isr
void myTMR1_isr()
{
    IO_inv(LED);
}

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    
    // set TMR1 ticker
    TMR1_ticker(500, myTMR1_isr);
    
    // enable interrupt
    ENABLE_interrupt();

    while(1)
    {

    }
}
