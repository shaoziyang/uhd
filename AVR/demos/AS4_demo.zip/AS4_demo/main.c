/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5
#define LED_2   B, 4
#define LED_3   B, 3
#define LED_4   B, 2

uint8_t dat;

// TXD isr
void UART0_TXD_ISR()
{
    // invert LED after send a byte
    IO_inv(LED);
}

// RXD isr
void UART0_RXD_ISR()
{
    dat = UART0_get();
    UART0_put(dat%10+'0');
}

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);

    // set UART baudrate and ISR
    UART0_init(9600, UART0_TXD_ISR, UART0_RXD_ISR, NULL);

    // enable interrupt
    ENABLE_interrupt();
    
    while(1)
    {

    }
}
