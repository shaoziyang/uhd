/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

uint8_t i;

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);
    
    while(1)
    {
        // set system clock division as 1
        // please compare delay_MS time
        OSC_freq_div(OSC_DIV_1);
        for(i = 0; i < 10; i++)
        {
            IO_inv(LED);
            delay_MS(100);
        }

        // set system clock division as 2
        OSC_freq_div(OSC_DIV_2);
        for(i = 0; i < 10; i++)
        {
            IO_inv(LED);
            delay_MS(100);
        }
        
        // set system clock division as 4
        OSC_freq_div(OSC_DIV_4);
        for(i = 0; i < 10; i++)
        {
            IO_inv(LED);
            delay_MS(100);
        }

        // set system clock division as 16
        OSC_freq_div(OSC_DIV_16);
        for(i = 0; i < 10; i++)
        {
            IO_inv(LED);
            delay_MS(100);
        }

    }
}
