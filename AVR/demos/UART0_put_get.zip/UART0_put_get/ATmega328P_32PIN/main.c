/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5
#define LED_2   B, 4
#define LED_3   B, 3
#define LED_4   B, 2

uint8_t dat = '>';

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);

    // set baudrate to 9600, no isr
    UART0_init(9600, NULL, NULL, NULL);
    
    while(1)
    {
        // if uart can read
        if(UART0_readable())
        {
            // read a byte
            dat = UART0_get();
        }

        // send a byte
        UART0_put(dat);

        IO_inv(LED);
        delay_MS(200);
    }
}
