/*
 * GccApplication1.c
 *
 * Created: 2015/11/3 14:25:53
 * Author : szy
 */ 

#include "uhd.h"

#define LED     B, 5

#define KEY0    D, 2
#define KEY1    D, 3

// EXTINT isr
void myEXTINT_isr(void)
{
	IO_inv(LED);
}

int main()
{
	// set LED pin as output
	IO_dir(LED, IO_OUTPUT);
	IO_clr(LED);
	
	// set INPUT and pullup
	IO_dir(KEY0, IO_INPUT);
	IO_pullup(KEY0, PULLUP_ENABLE);
	IO_dir(KEY1, IO_INPUT);
	IO_pullup(KEY1, PULLUP_ENABLE);
	
	// EXTINT initial
	EXTINT0_init(EXTINT_ONRISING, myEXTINT_isr);
	EXTINT1_init(EXTINT_ONFALLING, myEXTINT_isr);
	
	// Enable global interrupt
	ENABLE_interrupt();
	
	while(1)
	{


	}
}

