/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

// define PORT
#define myPORT  D

int main()
{
    // set PORT as output
    PORT_dir(myPORT, PORT_OUTPUT);
    
    while(1)
    {
        // invert PORT output
        PORT_inv(myPORT);
        delay_MS(200);
    }
}
