/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

#define BUTTON  B, 0

uint8_t cnt;
int main()
{
    IO_dir(LED, IO_OUTPUT);
    
    WDT_set(WDTO_DISABLE);
    
    for(cnt = 0; cnt < 10; cnt++)
    {
        IO_inv(LED);
        delay_MS(100);
    }
    
    while(1)
    {
        IO_inv(LED);
        WDT_sleep_MS(1000);
    }
}
