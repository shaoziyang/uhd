/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"
#include <stdio.h>

#define LED     B, 5

uint16_t dat;
char buf[20];

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    IO_clr(LED);

    // set internal reference
    ADC_init(AREF_INT);

    // set uart baudrate
    UART0_init(9600, NULL, NULL, NULL);
    
    while(1)
    {
        delay_MS(500);
        
        // get ADC0
        dat = ADC_get(0);

        // printf result to uart
        sprintf(buf, "%d\r\n", dat);
        UART0_puts(buf);

        // invert LED
        IO_inv(LED);
    }
}
