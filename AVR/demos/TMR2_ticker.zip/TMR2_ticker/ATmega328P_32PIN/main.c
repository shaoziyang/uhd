/* 
 * Universal hardware driver for microcontrollers
 * 
 * File:     demo.c
 * Descript: Demo file to test UHD function.
 *
 * Platform: AVR
 * Board:    Arduino Nano 3
 * Compiler: GNU Toolchain for Atmel AVR8/WinAVR
 * Version:  1.0
 * 
 * Author:   shaoziyang
 * Email:    shaoziyang@outlook.com
 * Date:     2015-Octo
 *
 */

#include "uhd.h"

#define LED     B, 5

// user isr function
void myTMR2_isr()
{
    IO_inv(LED);
}

int main()
{
    // set LED pin as output
    IO_dir(LED, IO_OUTPUT);
    
    // set TMR2 ticker
    TMR2_ticker(1000, myTMR2_isr);
    
    // enable interrupt
    ENABLE_interrupt();

    while(1)
    {

    }
}
